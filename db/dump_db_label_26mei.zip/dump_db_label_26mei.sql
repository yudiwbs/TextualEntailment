-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.42 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.2.0.4947
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table rte3.disc_t_rte3_label
CREATE TABLE IF NOT EXISTS `disc_t_rte3_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kalimat` int(11) DEFAULT NULL,
  `t` text,
  `t_gram_structure` text,
  `t_type_dependency` text,
  `jenis` varchar(50) DEFAULT NULL,
  `id_source` int(11) DEFAULT NULL,
  `label` int(11) DEFAULT NULL COMMENT '1: terpilih',
  `t_ner` text,
  PRIMARY KEY (`id`),
  KEY `id_kalimat` (`id_kalimat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.


-- Dumping structure for table rte3.rte3_label
CREATE TABLE IF NOT EXISTS `rte3_label` (
  `id_internal` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `isEntail` tinyint(1) DEFAULT NULL,
  `task` varchar(60) DEFAULT NULL,
  `t` text NOT NULL,
  `h` text NOT NULL,
  `t_gram_structure` text,
  `t_type_dependency` text,
  `h_gram_structure` text,
  `h_type_dependency` text,
  `id_disc_t` int(11) DEFAULT NULL,
  `t_preprocoref` text,
  `h_preprocoref` text,
  `t_preprogabungan` text,
  `h_ner` text,
  PRIMARY KEY (`id_internal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
